﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraphicsLib
{
    public abstract class Shape
    {
        public abstract String Draw();
    }
   
    public class Rectangle : Shape
    {
        public Rectangle() { }
        public override string Draw()
        {
            return "Rectangle";
        }
    }
}
