﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraphicsLib
{
    public class Line : Shape
    {
        private int startPoint, endPoint;

        public Line(int startPoint, int endPoint)
        {
            this.startPoint = startPoint;
            this.endPoint = endPoint;
        }

        public int StartPoint { get => startPoint; set => startPoint = value; }
        public int EndPoint { get => endPoint; set => endPoint = value; }

        public override string Draw()
        {
            return "Line";
        }
        public override string ToString()
        {
            return "StartPoint:" + startPoint + "EndPoint:" + endPoint;
        }
    }
}
