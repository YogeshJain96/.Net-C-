﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRLib
{
    public abstract class Employee
    {
        /* public abstract int ComputePay();*/
        public virtual int ComputePay()
        {
            return 30000;
        }
    }
    public class Manager : Employee
    {
        /*public override int ComputePay()
        {
            return 31000;
        }*/
    }
    public class SalesManager : Employee
    {
        public override int ComputePay()
        {
            return 11000;
        }
    }
}
