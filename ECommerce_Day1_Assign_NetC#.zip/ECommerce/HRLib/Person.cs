﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRLib
{
    public class Person
    {
       /*firstName, lastName,birthDate, email and location to 
        Person class HRLib project.*/
        private String firstName;
        private String lastName;
        private DateTime birthdate;
        private String email;
        private String loc;

        public Person()
        { 
        }
        public Person(String fname, String lname, DateTime bdate, String email, String loc)
        {
            this.firstName = fname;
            this.lastName = lname;
            this.birthdate = bdate;
            this.email = email;
            this.loc = loc;

        }

        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public DateTime Birthdate { get => birthdate; set => birthdate = value; }
        public string Email { get => email; set => email = value; }
        public string Loc { get => loc; set => loc = value; }

        public override string ToString()
        {
            return firstName +" "+ lastName + " " + birthdate + " " + email + " " + loc;
        }
        ~Person()
        {
            
        }
    }
}
