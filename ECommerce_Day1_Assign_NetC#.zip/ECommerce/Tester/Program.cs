﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HRLib;
using GraphicsLib;

namespace Tester
{

    class Complex
    {
        private int real;
        private int img;
        private static int count=0;

        public Complex()
        {
            count++;
        }
        public Complex(int real, int img)
        {
            this.real = real;
            this.img = img;
            count++;
        }
        ~Complex() { }

        public int Real 
        {
            get { return this.real; }
            set { this.real = value;}
        }
        public int Img
        {
            get { return this.img; }
            set { this.img = value; }
        }
        public int Count
        {
            get { return count; }
            set { count = value; }
        }

        public static Complex operator +(Complex c1,Complex c2)
        {
            return new Complex(c1.real+c2.real,c1.img+c2.img);
        }
        public static Complex operator -(Complex c1, Complex c2)
        {
            return new Complex(c1.real - c2.real, c1.img - c2.img);
        }
        public override string ToString()
        {
            return "Real"+real+"Imag"+img;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello");
            Complex c1 = new Complex(11,15);
            Complex c2 = new Complex(5,5);
            Complex c3 = new Complex();
            c3 = c1 + c2;
            
            Console.WriteLine(c3);
            c3 = c1 - c2;
            Console.WriteLine(c3);

            Person p = new Person("Shaan", "Hada", new DateTime(1995, 04, 14), "shantnuhada91@gmail.com", "Pune");
            Console.WriteLine(p);
            //Console.ReadLine();

            Employee m = new Manager();
            Console.WriteLine(m.ComputePay());
           // Console.ReadLine();

            Employee sm  = new SalesManager();
            Console.WriteLine(sm.ComputePay());
            //Console.ReadLine();


            Shape point = new Point(12, 15);
            Console.WriteLine(point.Draw());

            Shape line = new Line(2,5);
            Console.WriteLine(line);
            Console.WriteLine(line.Draw());
            Shape Rect = new Rectangle();
            Console.WriteLine(Rect.Draw());

            Console.ReadLine();
        }
    }
}
