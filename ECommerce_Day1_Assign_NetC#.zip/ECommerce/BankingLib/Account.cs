﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingLib
{
    public class Account
    {
        private int balance;

        public Account(int balance)
        {
            this.Balance = balance;
        }

        public int Withdraw(int amt)
        {
            balance = balance - amt;
            return balance;
        }
        public int Deposit(int amt)
        {
            balance = balance + amt;
            return balance;
        }
        public override string ToString()
        {
            return "Balance:" + balance;
        }
        public int Balance { get => balance; set => balance = value; }
    }
}
