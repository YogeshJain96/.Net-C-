﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankingLib;

namespace Printer
{
    class Program
    {
        static void Main(string[] args)
        {
            Account acc = new Account(100000);
            Console.WriteLine(acc);
            Console.WriteLine(acc.Withdraw(1000));
            Console.WriteLine(acc.Deposit(22000));
            Console.ReadLine();
        }
    }
}
